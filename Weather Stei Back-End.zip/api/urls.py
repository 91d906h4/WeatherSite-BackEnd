from django.urls import path
from . import views

urlpatterns = [
    path('<str:key>/<str:id>', views.get, name="Index"),
]